Animal Gear - Null Outfit & Human Guard 1.5 v2

Load after Animal Gear and Animal Equipment.

Behavior:
- Player animals default to None / 无方案.
- None / 无方案 is a permanent animal-only outfit selector entry and can always be selected again after choosing another policy by mistake.
- Colonist outfit UI and policies are untouched; colonists never see this option.
- While None / 无方案 is selected, JobGiver_OptimizeApparel is skipped for that animal, so it does not search for, optimize, replace, or automatically wear apparel.
- Selecting a normal apparel policy re-enables Animal Gear apparel optimization normally.
- On the first load of an existing save, player animals still using the vanilla default Anything policy are migrated once to None. Custom animal policies are preserved.
- After that one-time migration, explicitly selecting Anything remains respected.
- Strict apparel with the Animal tag is removed from human defaultOutfitTags.
- Humanlike pawns cannot wear strict Animal-tagged apparel through ApparelUtility.HasPartsToWear.
- After starting-apparel generation, any strict Animal-tagged apparel directly injected onto a Humanlike pawn is removed as a final safeguard.
- Shared/AnimalCompatible equipment is not blocked; only strict Animal-tagged apparel is guarded.
