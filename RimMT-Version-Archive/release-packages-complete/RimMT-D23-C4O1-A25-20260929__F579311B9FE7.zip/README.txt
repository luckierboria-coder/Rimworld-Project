RimMT D.2.3-C4O1 + Clean Pathfinding A2.5 performance trial

Baseline: the supplied good-run report (runtime was D.2.3 with the C.4 subsystem).
Retained: T34-B, T34-D.1.3, S4, S5.1, DoBill, CommonSense, T21, T22, T28, T32.
Removed from production: Refuel/Fire/Pawn/HoldingTarget C.4 census work and D.2.3 asset cleanup coalescer.
C.4 authoritative path: HaulCorpses invariant type negatives only, with live parity.
A2.5: exactly one FinishFrame endpoint IL replacement; no PathFinder, StartPath, Root_Play,
Diagnostics, cache, queue, telemetry, or per-frame patch.
Performance comparison profile: disable RimMT Diagnostics v0.20.7 for the first A/B run.
